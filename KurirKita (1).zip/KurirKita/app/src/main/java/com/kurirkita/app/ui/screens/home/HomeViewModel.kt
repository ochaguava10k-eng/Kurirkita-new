package com.kurirkita.app.ui.screens.home

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.kurirkita.app.data.model.Order
import com.kurirkita.app.data.prefs.RingtonePrefs
import com.kurirkita.app.data.repo.OrderRepository
import com.kurirkita.app.notification.OrderNotificationHelper
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * Mengatur status online/offline driver dan menangani order masuk:
 * memicu bunyi nada dering + getar sesuai preferensi di menu pengaturan.
 */
class HomeViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = OrderRepository()
    private val ringtonePrefs = RingtonePrefs(application)

    private val _isOnline = MutableStateFlow(false)
    val isOnline: StateFlow<Boolean> = _isOnline

    private val _incomingOrder = MutableStateFlow<Order?>(null)
    val incomingOrder: StateFlow<Order?> = _incomingOrder

    private val _activeOrder = MutableStateFlow<Order?>(null)
    val activeOrder: StateFlow<Order?> = _activeOrder

    private var listenJob: Job? = null

    fun setOnline(online: Boolean) {
        _isOnline.value = online
        if (online) startListening() else stopListening()
    }

    private fun startListening() {
        listenJob?.cancel()
        listenJob = viewModelScope.launch {
            repository.incomingOrders().collect { order ->
                if (_activeOrder.value == null && _incomingOrder.value == null) {
                    _incomingOrder.value = order
                    notifyIncomingOrder()
                }
            }
        }
    }

    private fun stopListening() {
        listenJob?.cancel()
        listenJob = null
        OrderNotificationHelper.stopSound()
        _incomingOrder.value = null
    }

    private fun notifyIncomingOrder() {
        viewModelScope.launch {
            val context = getApplication<Application>()
            val soundOn = ringtonePrefs.soundEnabled.first()
            val vibrateOn = ringtonePrefs.vibrateEnabled.first()
            val uri = ringtonePrefs.ringtoneUri.first()
            if (soundOn) {
                OrderNotificationHelper.playIncomingOrderSound(context, uri)
            }
            if (vibrateOn) {
                OrderNotificationHelper.vibrate(context)
            }
        }
    }

    fun acceptOrder() {
        OrderNotificationHelper.stopSound()
        _activeOrder.value = _incomingOrder.value
        _incomingOrder.value = null
    }

    fun rejectOrder() {
        OrderNotificationHelper.stopSound()
        _incomingOrder.value = null
    }

    fun expireOrder() {
        OrderNotificationHelper.stopSound()
        _incomingOrder.value = null
    }

    fun completeActiveOrder() {
        _activeOrder.value = null
    }

    override fun onCleared() {
        super.onCleared()
        OrderNotificationHelper.stopSound()
    }
}
