package com.kurirkita.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.kurirkita.app.ui.navigation.KurirKitaNavGraph
import com.kurirkita.app.ui.theme.KurirKitaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            KurirKitaTheme {
                KurirKitaNavGraph()
            }
        }
    }
}
