package com.kurirkita.app.data.repo

import com.kurirkita.app.data.model.WalletTransaction

class WalletRepository {

    fun getBalance(): Long = 187500

    fun getTransactions(): List<WalletTransaction> = listOf(
        WalletTransaction("TRX-1", "Order ORD-1041 selesai", 15000, true, "Hari ini, 14:20"),
        WalletTransaction("TRX-2", "Order ORD-1038 selesai", 12000, true, "Hari ini, 11:05"),
        WalletTransaction("TRX-3", "Penarikan saldo", 100000, false, "Kemarin, 19:40"),
        WalletTransaction("TRX-4", "Order ORD-1029 selesai", 18000, true, "Kemarin, 16:12"),
        WalletTransaction("TRX-5", "Bonus performa mingguan", 25000, true, "2 hari lalu")
    )
}
