package com.kurirkita.app.data.repo

import kotlinx.coroutines.delay

/** Autentikasi contoh untuk demo, belum terhubung ke server mana pun. */
class AuthRepository {
    suspend fun login(phone: String, password: String): Result<Unit> {
        delay(800)
        return if (phone.length >= 9 && password.length >= 4) {
            Result.success(Unit)
        } else {
            Result.failure(IllegalArgumentException("Nomor HP atau kata sandi tidak valid"))
        }
    }
}
