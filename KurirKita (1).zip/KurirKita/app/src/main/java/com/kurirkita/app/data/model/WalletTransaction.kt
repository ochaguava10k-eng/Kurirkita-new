package com.kurirkita.app.data.model

data class WalletTransaction(
    val id: String,
    val title: String,
    val amount: Long,
    val isCredit: Boolean,
    val dateLabel: String
)
