package com.kurirkita.app.data.model

data class Order(
    val id: String,
    val customerName: String,
    val pickupAddress: String,
    val dropAddress: String,
    val distanceKm: Double,
    val fee: Long,
    val itemsSummary: String,
    val status: OrderStatus = OrderStatus.INCOMING
)

enum class OrderStatus {
    INCOMING, ACCEPTED, PICKED_UP, DELIVERED, REJECTED, EXPIRED
}
