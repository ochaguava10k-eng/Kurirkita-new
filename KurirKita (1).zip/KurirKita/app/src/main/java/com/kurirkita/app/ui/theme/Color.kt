package com.kurirkita.app.ui.theme

import androidx.compose.ui.graphics.Color

val BrandPrimary = Color(0xFF0F9D58)
val BrandSecondary = Color(0xFFFFC107)
val BackgroundLight = Color(0xFFF5F7F6)
val SurfaceLight = Color(0xFFFFFFFF)
val TextPrimary = Color(0xFF1B1B1B)
val DangerColor = Color(0xFFE53935)
