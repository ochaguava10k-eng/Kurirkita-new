package com.kurirkita.app.ui.screens.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.kurirkita.app.data.model.Order
import kotlinx.coroutines.delay

/** Dialog order masuk dengan hitung mundur, muncul bersamaan dengan nada dering. */
@Composable
fun IncomingOrderDialog(
    order: Order,
    onAccept: () -> Unit,
    onReject: () -> Unit,
    onExpire: () -> Unit
) {
    var secondsLeft by remember(order.id) { mutableStateOf(15) }

    LaunchedEffect(order.id) {
        while (secondsLeft > 0) {
            delay(1000)
            secondsLeft -= 1
        }
        onExpire()
    }

    AlertDialog(
        onDismissRequest = { },
        confirmButton = {
            Button(onClick = onAccept) { Text("Terima") }
        },
        dismissButton = {
            OutlinedButton(onClick = onReject) { Text("Tolak") }
        },
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Order Masuk")
                Text("${secondsLeft}s", color = MaterialTheme.colorScheme.error)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Pelanggan: ${order.customerName}")
                Text("Jemput: ${order.pickupAddress}")
                Text("Antar: ${order.dropAddress}")
                Text("Jarak: ${order.distanceKm} km")
                Text("Jenis: ${order.itemsSummary}")
                Text(
                    "Estimasi fee: Rp${"%,d".format(order.fee).replace(',', '.')}",
                    color = MaterialTheme.colorScheme.primary
                )
            }
        },
        shape = RoundedCornerShape(16.dp)
    )
}
