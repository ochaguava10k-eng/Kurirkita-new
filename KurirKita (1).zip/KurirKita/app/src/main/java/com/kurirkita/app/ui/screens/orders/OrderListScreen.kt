package com.kurirkita.app.ui.screens.orders

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.kurirkita.app.data.model.Order

private val dummyHistory = listOf(
    Order("ORD-1041", "Rina", "Jl. Merdeka No. 12", "Jl. Sudirman No. 45", 3.2, 15000, "Paket dokumen"),
    Order("ORD-1038", "Budi", "Ruko Graha Niaga Blok C2", "Perumahan Griya Asri No. 9", 5.1, 12000, "Makanan & minuman"),
    Order("ORD-1029", "Sari", "Jl. Kenanga No. 8", "Jl. Melati No. 20", 2.4, 18000, "Paket kecil")
)

@Composable
fun OrderListScreen(navController: NavController) {
    Scaffold(topBar = { TopAppBar(title = { Text("Riwayat Order") }) }) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(dummyHistory) { order ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(order.id)
                        Text("${order.pickupAddress} -> ${order.dropAddress}")
                        Text("Rp${"%,d".format(order.fee).replace(',', '.')} - ${order.distanceKm} km")
                    }
                }
            }
        }
    }
}
