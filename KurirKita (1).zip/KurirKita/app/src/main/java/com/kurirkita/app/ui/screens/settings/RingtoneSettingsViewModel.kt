package com.kurirkita.app.ui.screens.settings

import android.app.Application
import android.content.Context
import android.media.RingtoneManager
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.kurirkita.app.data.prefs.RingtonePrefs
import com.kurirkita.app.notification.OrderNotificationHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class RingtoneSettingsViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = RingtonePrefs(application)

    private val _ringtoneName = MutableStateFlow("Memuat...")
    val ringtoneName: StateFlow<String> = _ringtoneName

    private val _soundEnabled = MutableStateFlow(true)
    val soundEnabled: StateFlow<Boolean> = _soundEnabled

    private val _vibrateEnabled = MutableStateFlow(true)
    val vibrateEnabled: StateFlow<Boolean> = _vibrateEnabled

    private var savedUri: Uri? = null

    init {
        viewModelScope.launch {
            val uriString = prefs.ringtoneUri.first()
            savedUri = uriString?.let { Uri.parse(it) }
            updateRingtoneName(getApplication())
            _soundEnabled.value = prefs.soundEnabled.first()
            _vibrateEnabled.value = prefs.vibrateEnabled.first()
        }
    }

    fun currentUriOrDefault(): Uri {
        return savedUri ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
    }

    fun onRingtonePicked(context: Context, uri: Uri?) {
        savedUri = uri
        viewModelScope.launch {
            prefs.setRingtoneUri(uri?.toString())
            updateRingtoneName(context)
        }
    }

    fun setSoundEnabled(enabled: Boolean) {
        _soundEnabled.value = enabled
        viewModelScope.launch { prefs.setSoundEnabled(enabled) }
    }

    fun setVibrateEnabled(enabled: Boolean) {
        _vibrateEnabled.value = enabled
        viewModelScope.launch { prefs.setVibrateEnabled(enabled) }
    }

    fun testRingtone(context: Context) {
        OrderNotificationHelper.playIncomingOrderSound(context, savedUri?.toString())
    }

    private fun updateRingtoneName(context: Context) {
        val uri = savedUri
        _ringtoneName.value = if (uri == null) {
            "Default (nada notifikasi sistem)"
        } else {
            try {
                RingtoneManager.getRingtone(context, uri)?.getTitle(context) ?: "Nada dering dipilih"
            } catch (e: Exception) {
                "Nada dering dipilih"
            }
        }
    }
}
