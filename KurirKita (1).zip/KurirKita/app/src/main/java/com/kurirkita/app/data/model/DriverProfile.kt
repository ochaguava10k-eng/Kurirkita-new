package com.kurirkita.app.data.model

data class DriverProfile(
    val name: String,
    val phone: String,
    val vehiclePlate: String,
    val rating: Double,
    val totalDeliveries: Int
)
