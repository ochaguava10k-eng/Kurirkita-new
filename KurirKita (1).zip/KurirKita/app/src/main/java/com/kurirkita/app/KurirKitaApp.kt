package com.kurirkita.app

import android.app.Application
import com.kurirkita.app.notification.OrderNotificationHelper

class KurirKitaApp : Application() {
    override fun onCreate() {
        super.onCreate()
        OrderNotificationHelper.ensureChannel(this)
    }
}
