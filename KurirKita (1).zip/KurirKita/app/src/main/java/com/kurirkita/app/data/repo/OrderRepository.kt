package com.kurirkita.app.data.repo

import com.kurirkita.app.data.model.Order
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlin.random.Random

/**
 * Sumber data order. Saat ini mensimulasikan order masuk secara berkala
 * selagi driver online, sebagai pengganti koneksi ke server sungguhan.
 */
class OrderRepository {

    private val sampleCustomers = listOf("Rina", "Budi", "Sari", "Andi", "Dewi", "Fajar", "Lina")
    private val sampleAreas = listOf(
        "Jl. Merdeka No. 12" to "Jl. Sudirman No. 45",
        "Jl. Kenanga No. 8" to "Jl. Melati No. 20",
        "Ruko Graha Niaga Blok C2" to "Perumahan Griya Asri No. 9",
        "Jl. Ahmad Yani No. 3" to "Jl. Diponegoro No. 77"
    )
    private val sampleItems = listOf("Paket dokumen", "Makanan & minuman", "Paket kecil", "Belanjaan")

    fun incomingOrders(): Flow<Order> = flow {
        var counter = 1
        while (true) {
            delay(Random.nextLong(8_000, 18_000))
            val (pickup, drop) = sampleAreas.random()
            val order = Order(
                id = "ORD-${1000 + counter}",
                customerName = sampleCustomers.random(),
                pickupAddress = pickup,
                dropAddress = drop,
                distanceKm = Math.round(Random.nextDouble(1.0, 9.5) * 10) / 10.0,
                fee = Random.nextInt(8, 26) * 1000L,
                itemsSummary = sampleItems.random()
            )
            counter += 1
            emit(order)
        }
    }
}
