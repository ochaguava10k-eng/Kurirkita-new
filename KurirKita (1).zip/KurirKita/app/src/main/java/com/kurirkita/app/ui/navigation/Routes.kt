package com.kurirkita.app.ui.navigation

object Routes {
    const val LOGIN = "login"
    const val HOME = "home"
    const val ORDERS = "orders"
    const val WALLET = "wallet"
    const val PROFILE = "profile"
    const val RINGTONE_SETTINGS = "ringtone_settings"
}
