package com.kurirkita.app.data.prefs

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "kurirkita_settings")

/**
 * Menyimpan preferensi notifikasi order masuk: nada dering yang dipilih,
 * serta sakelar bunyi dan getar. Dipakai oleh menu "Nada Dering Order Masuk".
 */
class RingtonePrefs(private val context: Context) {

    private object Keys {
        val RINGTONE_URI = stringPreferencesKey("order_ringtone_uri")
        val SOUND_ENABLED = booleanPreferencesKey("order_sound_enabled")
        val VIBRATE_ENABLED = booleanPreferencesKey("order_vibrate_enabled")
    }

    val ringtoneUri: Flow<String?> = context.dataStore.data.map { it[Keys.RINGTONE_URI] }
    val soundEnabled: Flow<Boolean> = context.dataStore.data.map { it[Keys.SOUND_ENABLED] ?: true }
    val vibrateEnabled: Flow<Boolean> = context.dataStore.data.map { it[Keys.VIBRATE_ENABLED] ?: true }

    suspend fun setRingtoneUri(uri: String?) {
        context.dataStore.edit { prefs ->
            if (uri == null) prefs.remove(Keys.RINGTONE_URI) else prefs[Keys.RINGTONE_URI] = uri
        }
    }

    suspend fun setSoundEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.SOUND_ENABLED] = enabled }
    }

    suspend fun setVibrateEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.VIBRATE_ENABLED] = enabled }
    }
}
