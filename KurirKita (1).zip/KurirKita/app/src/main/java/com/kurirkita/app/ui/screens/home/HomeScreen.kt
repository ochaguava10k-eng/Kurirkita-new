package com.kurirkita.app.ui.screens.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.kurirkita.app.ui.navigation.Routes

@Composable
fun HomeScreen(navController: NavController, viewModel: HomeViewModel = viewModel()) {
    val isOnline by viewModel.isOnline.collectAsState()
    val incomingOrder by viewModel.incomingOrder.collectAsState()
    val activeOrder by viewModel.activeOrder.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("KurirKita") },
                actions = {
                    IconButton(onClick = { navController.navigate(Routes.RINGTONE_SETTINGS) }) {
                        Icon(Icons.Default.Notifications, contentDescription = "Nada dering order masuk")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Status", fontWeight = FontWeight.Medium)
                        Text(if (isOnline) "Online — siap menerima order" else "Offline")
                    }
                    Switch(checked = isOnline, onCheckedChange = { viewModel.setOnline(it) })
                }
            }

            if (activeOrder != null) {
                val order = activeOrder!!
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.LocalShipping, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Order aktif: ${order.id}", fontWeight = FontWeight.Medium)
                        }
                        Text("Jemput: ${order.pickupAddress}")
                        Text("Antar: ${order.dropAddress}")
                        Button(onClick = { viewModel.completeActiveOrder() }) {
                            Text("Tandai selesai")
                        }
                    }
                }
            } else if (isOnline) {
                Text("Menunggu order masuk...")
            }
        }
    }

    incomingOrder?.let { order ->
        IncomingOrderDialog(
            order = order,
            onAccept = { viewModel.acceptOrder() },
            onReject = { viewModel.rejectOrder() },
            onExpire = { viewModel.expireOrder() }
        )
    }
}
